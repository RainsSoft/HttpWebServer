namespace Tutorial
{
    interface Tutorial
    {
        void StartTutorial();
        void EndTutorial();

        string Name
        { get; }
    }
}
